import json
import psycopg2
import csv
from io import StringIO
import os
import boto3

def get_ssm_parameter(name, decrypt=True):
    """Fetch parameter value from AWS SSM Parameter Store"""
    ssm_client = boto3.client("ssm")
    response = ssm_client.get_parameter(Name=name, WithDecryption=decrypt)
    return response["Parameter"]["Value"]

def lambda_handler(event, context):
    
    # Database connection parameters
    db_config = {
            "host": get_ssm_parameter("/financialdb/host"),
            "port": int(get_ssm_parameter("/financialdb/port")),
            "database": get_ssm_parameter("/financialdb/database"),
            "user": get_ssm_parameter("/financialdb/user"),
            "password": get_ssm_parameter("/financialdb/password"),
        }

    try:
        # Establish the connection
        conn = psycopg2.connect(**db_config)
        cursor = conn.cursor()

        # Execute the query to fetch all rows from transactions table
        cursor.execute("SELECT * FROM transactions;")
        rows = cursor.fetchall()

        # Retrieve column names from the cursor description for CSV header
        column_names = [desc[0] for desc in cursor.description]

        # Write rows to CSV file
        '''
        with open("transactions.csv", "w", newline="") as csvfile:
            csv_writer = csv.writer(csvfile)
            csv_writer.writerow(column_names)  # Write header row
            csv_writer.writerows(rows)         # Write data rows
        
        '''

        # Save to CSV
        output = StringIO()
        writer = csv.writer(output)
        writer.writerow([desc[0] for desc in cursor.description])  # Write headers
        writer.writerows(rows)

        print("Data saved to CSV")

        print("Data has been successfully exported to transactions.csv")

    except Exception as error:
        print("Error while connecting to PostgreSQL", error)
        
    finally:
        # Ensure the cursor and connection are closed
        if cursor:
            cursor.close()
        if conn:
            conn.close()


    import boto3

    # AWS Configuration
    S3_BUCKET_NAME = "financial-data-raw-amk"
    S3_OBJECT_NAME = "transactions_data.csv"
    LOCAL_CSV_FILE = "transactions.csv"

    # Create an S3 client (uses credentials from AWS profile)
    s3_client = boto3.client("s3")

    try:
        #s3_client.upload_file(LOCAL_CSV_FILE, S3_BUCKET_NAME, S3_OBJECT_NAME)

        s3_client.put_object(Bucket=S3_BUCKET_NAME, Key=S3_OBJECT_NAME, Body=output.getvalue())
        print(f"File '{LOCAL_CSV_FILE}' uploaded successfully to S3.")
    except Exception as e:
        print(f"Error: {e}")


    return {
        'statusCode': 200,
        'body': json.dumps('Data transfer completed!')
    }
