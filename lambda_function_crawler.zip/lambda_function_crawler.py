import json
import boto3

glue_client = boto3.client('glue')

def lambda_handler(event, context):
    crawler_name = "financial-data-raw"

    # Start Glue Crawler
    response = glue_client.start_crawler(Name=crawler_name)
    
    print(f"Glue Crawler {crawler_name} started.")
    
    return {
        'statusCode': 200,
        'body': json.dumps(f"Glue Crawler {crawler_name} triggered successfully.")
    }
